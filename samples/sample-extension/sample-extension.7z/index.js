/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
(() => {
var exports = __webpack_exports__;
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/

Object.defineProperty(exports, "__esModule", ({ value: true }));
function main(context) {
    context.registerAction('global-icons', 100, 'menu', {}, 'Sample', () => {
        context.api.showDialog('info', 'Success!', {
            text: 'Hello World',
        }, [
            { label: 'Close' },
        ]);
    });
    return true;
}
exports["default"] = main;

})();

module.exports = __webpack_exports__;
/******/ })()
;
//# sourceMappingURL=sample-extension.js.map